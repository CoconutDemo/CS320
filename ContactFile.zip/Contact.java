package contact;

public class Contact {
	  private final String contactId;
	  private String firstName;
	  private String lastName;
	  private String phone;
	  private String address;

	  public Contact(String contactId, String firstName, String lastName, String phone, String address) { //contact constructor and objects
	      if (contactId == null || contactId.length() > 10) {
	          throw new IllegalArgumentException("Invalid length contact ID");
	      }
	      if (firstName == null || firstName.length() > 10) {
	          throw new IllegalArgumentException("Invalid length first name");
	      }
	      if (lastName == null || lastName.length() > 10) {
	          throw new IllegalArgumentException("Invalid length last name");
	      }
	      if (phone == null || phone.length() != 10 || !phone.matches("\\d+")) {
	          throw new IllegalArgumentException("Invalid length phone number");
	      }
	      if (address == null || address.length() > 30) {
	          throw new IllegalArgumentException("Invalid length address");
	      }

	      this.contactId = contactId;
	      this.firstName = firstName;
	      this.lastName = lastName;
	      this.phone = phone;
	      this.address = address;
	  }

	  public String getContactId() {
	      return contactId;
	  }

	  public String getFirstName() {
	      return firstName;
	  }

	  public void setFirstName(String firstName) {
	      if (firstName == null || firstName.length() > 10) {
	          throw new IllegalArgumentException("Invalid length first name");
	      }
	      this.firstName = firstName;
	  }

	  public String getLastName() {
	      return lastName;
	  }

	  public void setLastName(String lastName) {
	      if (lastName == null || lastName.length() > 10) {
	          throw new IllegalArgumentException("Invalid length last name");
	      }
	      this.lastName = lastName;
	  }

	  public String getPhone() {
	      return phone;
	  }

	  public void setPhone(String phone) {
	      if (phone == null || phone.length() != 10 || !phone.matches("\\d+")) {
	          throw new IllegalArgumentException("Invalid length phone number");
	      }
	      this.phone = phone;
	  }

	  public String getAddress() {
	      return address;
	  }

	  public void setAddress(String address) {
	      if (address == null || address.length() > 30) {
	          throw new IllegalArgumentException("Invalid length address");
	      }
	      this.address = address;
	  }
	}
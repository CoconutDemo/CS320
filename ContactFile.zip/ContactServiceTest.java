package contact;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceTest {

    private ContactService service;

    @BeforeEach
    public void setUp() {
        service = new ContactService();
    }

    @Test
    public void testAddContactSuccess() { //test contact successfully added
        Contact contact = new Contact("3", "Max", "Berg", "0987654321", "123 Main St");
        service.addContact(contact);
        assertNotNull(service);
    }

    @Test
    public void testAddContactFailure() { //adding contact failure test
        Contact contact1 = new Contact("3", "Max", "Berg", "0987654321", "123 Main St");
        service.addContact(contact1);
        assertThrows(IllegalArgumentException.class, () -> {
            service.addContact(contact1); 
        });
    }

    @Test
    public void testDeleteContact() { //test to delete contact
        Contact contact = new Contact("Delete", "Don", "Uce", "1234567890", "234 Main St");
        service.addContact(contact);
        service.deleteContact("Delete");
        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteContact("Delete"); 
        });
    }

    @Test
    public void testUpdateContactSuccess() { //test to update contact
        Contact contact = new Contact("Update", "Max", "Joe", "1234567890", "345 Main St");
        service.addContact(contact);
        service.updateContact("Update", "Mike", null, null, "456 Main St");
        assertEquals("Mike", contact.getFirstName());
        assertEquals("456 Main St", contact.getAddress());
    }

}

package contact;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class ContactTest{
	
    @Test
    public void testContactCreationSuccess() { //Test creation of contact
        // Test successful creation of a contact
        Contact contact = new Contact("3", "Max", "Berg", "1234567890", "123 Main St");
        assertNotNull(contact);
    }

	@Test
	public void testBadConstructor() { //test invalid phone length
       String contactId = "4";
       String firstName = "Max";
       String lastName = "Berg";
       String phone = "1";
       String address = "123 Main St";       
       
       Assertions.assertThrows(IllegalArgumentException.class, () -> {
       	new Contact(contactId, firstName, lastName, phone, address);
       });
	}
	
	@Test
	public void testGoodSetFirst() { //test first name good input
       String contactId = "3";
       String firstName = "Max";
       String lastName = "Berg";
       String phone = "1234567891";
       String address = "123 Main St";
		
       Contact testContact = new Contact(contactId, firstName, lastName, phone, address);   
       testContact.setFirstName("Test");        
       assertEquals("Test", testContact.getFirstName());
	}
	
	@Test
	public void testBadSetFirst() { //test null first name
       String contactId = "3";
       String firstName = "Greg";
       String lastName = "Berg";
       String phone = "1234567891";
       String address = "123 Main St";
		
       Contact testContact = new Contact(contactId, firstName, lastName, phone, address);   
       
       
       Assertions.assertThrows(IllegalArgumentException.class, () -> {
       	testContact.setFirstName(null);
       });
	}
	
	@Test
	public void testLongSetFirst() { //test first name length exceeding max
       String contactId = "3";
       String firstName = "Max";
       String lastName = "Berg";
       String phone = "1234567899";
       String address = "123 Main St";
		
       Contact testContact = new Contact(contactId, firstName, lastName, phone, address);   
       
       
       Assertions.assertThrows(IllegalArgumentException.class, () -> {
       	testContact.setFirstName("ExceedLengthFirstName");
       });
	}

	@Test
	public void testlongGetID() { //test Id exceeding length
       String contactId = "1234567899112233"; 
       String firstName = "Max";
       String lastName = "Berg";
       String phone = "1234567891";
       String address = "123 Main St";
		
       Assertions.assertThrows(IllegalArgumentException.class, () -> {
       	new Contact(contactId, firstName, lastName, phone, address);
       });
	}
	
	@Test
	public void testBadSetLast() { //test last name null
       String contactId = "3";
       String firstName = "Max";
       String lastName = "Berg";
       String phone = "1234567891";
       String address = "123 Main St";
		
       Contact testContact = new Contact(contactId, firstName, lastName, phone, address);   
       
       
       Assertions.assertThrows(IllegalArgumentException.class, () -> {
       	testContact.setLastName(null);
       });
	}
	
	@Test
	public void testLongSetLast() { //test last name exceeding length
       String contactId = "3";
       String firstName = "Max";
       String lastName = "Berg";
       String phone = "1234567891";
       String address = "123 Main St";
		
       Contact testContact = new Contact(contactId, firstName, lastName, phone, address);   
       
       
       Assertions.assertThrows(IllegalArgumentException.class, () -> {
       	testContact.setLastName("ExceedLengthLastName");
       });
	}
	
	@Test
	public void testGoodsetLast() { //test last name good input
       String contactId = "3";
       String firstName = "Max";
       String lastName = "Berg";
       String phone = "1234567891";
       String address = "123 Main St";
		
       Contact testContact = new Contact(contactId, firstName, lastName, phone, address);   
       testContact.setLastName("Test");        
       assertEquals("Test", testContact.getLastName());
	}
	
	@Test
	public void testBadSetPhone() { //test phone number null
       String contactId = "3";
       String firstName = "Max";
       String lastName = "Berg";
       String phone = "1234567891";
       String address = "123 Main St";
		
       Contact testContact = new Contact(contactId, firstName, lastName, phone, address);   
       
       
       Assertions.assertThrows(IllegalArgumentException.class, () -> {
       	testContact.setPhone(null);
       });
       
	}
	
	@Test
	public void testWrongLengthPhone() { //test phone number length != 10
       String contactId = "3";
       String firstName = "Max";
       String lastName = "Berg";
       String phone = "1234567891";
       String address = "123 Main St";
		
       Contact testContact = new Contact(contactId, firstName, lastName, phone, address);   
       
       
       Assertions.assertThrows(IllegalArgumentException.class, () -> {
       	testContact.setPhone("1");
       });
       Assertions.assertThrows(IllegalArgumentException.class, () -> {
       	testContact.setPhone("123456789101133445566");
       });
	}

	@Test
	public void testGoodPhone() { //test phone length at 10
       String contactId = "3";
       String firstName = "Max";
       String lastName = "Berg";
       String phone = "1234567891";
       String address = "123 Main St";
		
       Contact testContact = new Contact(contactId, firstName, lastName, phone, address);   

       testContact.setPhone("1732567891");        
       assertEquals("1732567891", testContact.getPhone());

	}
	
	@Test
	public void testNullSetAddress() { //test address null
       String contactId = "3";
       String firstName = "Max";
       String lastName = "Berg";
       String phone = "1234567891";
       String address = "123 Main St";
		
       Contact testContact = new Contact(contactId, firstName, lastName, phone, address);   
       
       Assertions.assertThrows(IllegalArgumentException.class, () -> {
       	testContact.setAddress(null);
       });
       
	}
	
	@Test
	public void testWrongLengthAddress() { //test address length exceeding >30
       String contactId = "3";
       String firstName = "Max";
       String lastName = "Berg";
       String phone = "1234567891";
       String address = "123 Main St";
		
       Contact testContact = new Contact(contactId, firstName, lastName, phone, address);   
       
       Assertions.assertThrows(IllegalArgumentException.class, () -> {
       	testContact.setAddress("Exceeded Length Address           >30");
       });
	}
	
	@Test
	public void testGoodAddress() { //test address good input
       String contactId = "3";
       String firstName = "Max";
       String lastName = "Berg";
       String phone = "1234567891";
       String address = "123 Main St";
		
       Contact testContact = new Contact(contactId, firstName, lastName, phone, address);   

       testContact.setAddress("183 Acceptable Address");        
       assertEquals("183 Acceptable Address", testContact.getAddress());

	}
	
}